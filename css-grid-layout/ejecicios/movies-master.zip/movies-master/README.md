# Reto de plazti
Este es un reto del [Curso de CSS Grid Layout](https://platzi.com/clases/css-grid-layout/) de [platzi](https://platzi.com/@jesusenriquerojas/)